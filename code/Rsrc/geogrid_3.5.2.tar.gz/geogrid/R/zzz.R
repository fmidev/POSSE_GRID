".onUnload" <- function (libpath){
  library.dynam.unload("geogrid",libpath)
}


