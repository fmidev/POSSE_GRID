".onUnload" <- function (libpath){
  library.dynam.unload("meteogrid",libpath)
}


